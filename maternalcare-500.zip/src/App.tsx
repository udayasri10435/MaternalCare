import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Calendar, 
  Heart, 
  LayoutDashboard, 
  Settings, 
  BookOpen, 
  Users, 
  Bell,
  ChevronRight,
  Plus,
  Droplets,
  Scale,
  Thermometer,
  Stethoscope,
  Server,
  Zap,
  ShieldCheck,
  AlertCircle,
  Pill,
  Clock,
  CheckCircle2,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { format } from 'date-fns';
import { cn } from './lib/utils';
import { Card, Badge } from './components/UI';
import { 
  MOCK_PREGNANCY, 
  MOCK_HEALTH_DATA, 
  MOCK_BP_DATA, 
  MOCK_APPOINTMENTS, 
  MOCK_SYMPTOMS,
  ALL_SERVICES,
  MOCK_MEDICATIONS,
  MOCK_NOTIFICATIONS
} from './mockData';
import { AppNotification } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Simulate "Medication Tracker" service scanning for low refills
  useEffect(() => {
    const lowRefillMeds = MOCK_MEDICATIONS.filter(m => m.remaining < 7);
    
    lowRefillMeds.forEach(med => {
      const notificationId = `refill-${med.id}`;
      // Check if notification already exists to avoid duplicates
      if (!notifications.some(n => n.id === notificationId)) {
        const newNotification: AppNotification = {
          id: notificationId,
          title: `Refill Alert: ${med.name}`,
          message: `Low supply (${med.remaining} days remaining). Please refill your ${med.dosage} dosage.`,
          type: 'medication',
          timestamp: new Date(),
          read: false,
          priority: 'high'
        };
        setNotifications(prev => [newNotification, ...prev]);
      }
    });
  }, []);

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const dismissNotification = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'health':
        return <HealthView />;
      case 'appointments':
        return <AppointmentsView />;
      case 'medications':
        return <MedicationsView />;
      case 'system':
        return <SystemMonitorView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] text-slate-900 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-rose-500 rounded-xl flex items-center justify-center shadow-lg shadow-rose-200">
            <Heart className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">MaternalCare</h1>
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">500-Microservice Architecture</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-4">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<Activity size={20} />} 
            label="Health Metrics" 
            active={activeTab === 'health'} 
            onClick={() => setActiveTab('health')} 
          />
          <NavItem 
            icon={<Calendar size={20} />} 
            label="Appointments" 
            active={activeTab === 'appointments'} 
            onClick={() => setActiveTab('appointments')} 
          />
          <NavItem 
            icon={<Pill size={20} />} 
            label="Medications" 
            active={activeTab === 'medications'} 
            onClick={() => setActiveTab('medications')} 
          />
          <NavItem 
            icon={<BookOpen size={20} />} 
            label="Education" 
            active={activeTab === 'education'} 
            onClick={() => setActiveTab('education')} 
          />
          <NavItem 
            icon={<Users size={20} />} 
            label="Community" 
            active={activeTab === 'community'} 
            onClick={() => setActiveTab('community')} 
          />
          <div className="pt-4 pb-2 px-3">
            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Infrastructure</p>
          </div>
          <NavItem 
            icon={<Server size={20} />} 
            label="System Monitor" 
            active={activeTab === 'system'} 
            onClick={() => setActiveTab('system')} 
          />
          <NavItem 
            icon={<Settings size={20} />} 
            label="Settings" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
            <img 
              src="https://picsum.photos/seed/user/100/100" 
              className="w-10 h-10 rounded-full border-2 border-white shadow-sm" 
              alt="User"
              referrerPolicy="no-referrer"
            />
            <div className="overflow-hidden">
              <p className="text-sm font-semibold truncate">Sarah Jenkins</p>
              <p className="text-xs text-slate-500">Week 24 • Day 3</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="h-16 bg-white/80 backdrop-blur-md border-bottom border-slate-200 sticky top-0 z-10 px-8 flex items-center justify-between">
          <h2 className="text-xl font-semibold capitalize">{activeTab.replace('-', ' ')}</h2>
          <div className="flex items-center gap-4">
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors relative"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
                )}
              </button>
              
              <AnimatePresence>
                {showNotifications && (
                  <>
                    <div 
                      className="fixed inset-0 z-20" 
                      onClick={() => setShowNotifications(false)}
                    ></div>
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 z-30 overflow-hidden"
                    >
                      <div className="p-4 border-b border-slate-100 flex justify-between items-center">
                        <h3 className="font-bold">Notifications</h3>
                        <Badge variant="default">{unreadCount} New</Badge>
                      </div>
                      <div className="max-h-96 overflow-y-auto custom-scrollbar">
                        {notifications.length === 0 ? (
                          <div className="p-8 text-center text-slate-400">
                            <p className="text-sm">No notifications yet</p>
                          </div>
                        ) : (
                          <div className="flex flex-col">
                            <AnimatePresence initial={false}>
                              {notifications.map(n => (
                                <motion.div 
                                  key={n.id}
                                  layout
                                  initial={{ opacity: 0, x: -20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  exit={{ opacity: 0, x: 20 }}
                                  transition={{ duration: 0.2 }}
                                  onClick={() => markAsRead(n.id)}
                                  className={cn(
                                    "p-4 border-b border-slate-50 cursor-pointer hover:bg-slate-50 transition-colors relative group",
                                    !n.read && "bg-rose-50/30"
                                  )}
                                >
                                  <div className="flex gap-3">
                                    <div className={cn(
                                      "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                                      n.type === 'medication' ? 'bg-blue-100 text-blue-600' : 
                                      n.type === 'appointment' ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-600'
                                    )}>
                                      {n.type === 'medication' ? <Pill size={16} /> : <Calendar size={16} />}
                                    </div>
                                    <div className="flex-1 min-w-0 pr-6">
                                      <p className="text-sm font-bold truncate">{n.title}</p>
                                      <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">{n.message}</p>
                                      <p className="text-[10px] text-slate-400 mt-1">{format(n.timestamp, 'h:mm a')}</p>
                                    </div>
                                    {!n.read && <div className="w-2 h-2 bg-rose-500 rounded-full mt-1.5"></div>}
                                  </div>
                                  <button 
                                    onClick={(e) => dismissNotification(e, n.id)}
                                    className="absolute right-2 top-4 p-1 text-slate-300 hover:text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <X size={14} />
                                  </button>
                                </motion.div>
                              ))}
                            </AnimatePresence>
                          </div>
                        )}
                      </div>
                      <button className="w-full py-3 text-sm font-semibold text-rose-500 hover:bg-rose-50 transition-colors border-t border-slate-100">
                        View All Notifications
                      </button>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
            <button className="flex items-center gap-2 bg-rose-500 text-white px-4 py-2 rounded-xl font-medium text-sm hover:bg-rose-600 transition-colors shadow-md shadow-rose-100">
              <Plus size={18} />
              <span>Log Metric</span>
            </button>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group",
        active 
          ? "bg-rose-50 text-rose-600 font-medium" 
          : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
      )}
    >
      <span className={cn("transition-colors", active ? "text-rose-600" : "text-slate-400 group-hover:text-slate-600")}>
        {icon}
      </span>
      <span className="text-sm">{label}</span>
      {active && <ChevronRight size={14} className="ml-auto" />}
    </button>
  );
}

function DashboardView() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Pregnancy Progress */}
      <Card className="lg:col-span-2 overflow-hidden relative">
        <div className="flex flex-col md:flex-row gap-8 items-center">
          <div className="relative w-48 h-48">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                fill="transparent"
                stroke="#F1F5F9"
                strokeWidth="12"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                fill="transparent"
                stroke="#F43F5E"
                strokeWidth="12"
                strokeDasharray={552.92}
                strokeDashoffset={552.92 * (1 - 24 / 40)}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-bold text-slate-900">24</span>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Weeks</span>
            </div>
          </div>
          <div className="flex-1 space-y-4">
            <div>
              <Badge variant="success">Trimester 2</Badge>
              <h3 className="text-2xl font-bold mt-2">Your baby is the size of an {MOCK_PREGNANCY.babySize}</h3>
              <p className="text-slate-500 mt-1">You are 60% through your pregnancy journey. Keep going, Sarah!</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-[10px] uppercase font-bold text-slate-400">Due Date</p>
                <p className="font-semibold">{format(MOCK_PREGNANCY.dueDate, 'MMM dd, yyyy')}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <p className="text-[10px] uppercase font-bold text-slate-400">Days to Go</p>
                <p className="font-semibold">112 Days</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Baby Preview */}
      <Card title="Fetal Development" subtitle="Week 24 Visualizer">
        <div className="aspect-square rounded-xl overflow-hidden bg-rose-50 flex items-center justify-center relative group">
          <img 
            src={MOCK_PREGNANCY.babyImage} 
            className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-700" 
            alt="Baby visualization"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-rose-500/40 to-transparent"></div>
          <div className="absolute bottom-4 left-4 text-white">
            <p className="text-xs font-medium opacity-80">Current Weight</p>
            <p className="text-lg font-bold">~600 grams</p>
          </div>
        </div>
      </Card>

      {/* Health Quick Stats */}
      <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon={<Scale className="text-blue-500" />} label="Weight" value="66.8 kg" trend="+0.6 kg" />
        <StatCard icon={<Activity className="text-rose-500" />} label="Blood Pressure" value="122/82" trend="Normal" />
        <StatCard icon={<Droplets className="text-cyan-500" />} label="Hydration" value="1.8 / 2.5L" trend="72%" />
        <StatCard icon={<Thermometer className="text-amber-500" />} label="Temperature" value="36.6 °C" trend="Stable" />
      </div>

      {/* Upcoming Appointments */}
      <Card title="Upcoming Care" className="lg:col-span-2">
        <div className="space-y-4">
          {MOCK_APPOINTMENTS.map(appt => (
            <div key={appt.id} className="flex items-center gap-4 p-4 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer group">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex flex-col items-center justify-center text-slate-500 group-hover:bg-white group-hover:shadow-sm transition-all">
                <span className="text-[10px] font-bold uppercase">{format(appt.date, 'MMM')}</span>
                <span className="text-lg font-bold leading-none">{format(appt.date, 'dd')}</span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-slate-900">{appt.title}</h4>
                <p className="text-sm text-slate-500">{appt.provider} • {appt.location}</p>
              </div>
              <Badge variant={appt.type === 'lab' ? 'warning' : 'default'}>{appt.type}</Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Symptoms */}
      <Card title="Recent Symptoms">
        <div className="space-y-4">
          {MOCK_SYMPTOMS.map(symp => (
            <div key={symp.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  symp.severity === 'high' ? 'bg-rose-500' : symp.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500'
                )}></div>
                <span className="text-sm font-medium">{symp.type}</span>
              </div>
              <span className="text-xs text-slate-400">{format(symp.timestamp, 'h:mm a')}</span>
            </div>
          ))}
          <button className="w-full py-2 text-sm font-medium text-rose-500 hover:text-rose-600 transition-colors">
            View All Symptoms
          </button>
        </div>
      </Card>
    </div>
  );
}

function StatCard({ icon, label, value, trend }: { icon: React.ReactNode, label: string, value: string, trend: string }) {
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center">
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{label}</p>
        <div className="flex items-baseline gap-2">
          <span className="text-xl font-bold">{value}</span>
          <span className="text-[10px] font-bold text-emerald-500">{trend}</span>
        </div>
      </div>
    </Card>
  );
}

function HealthView() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card title="Weight Progression" subtitle="Last 30 days">
          <div className="h-[300px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_HEALTH_DATA}>
                <defs>
                  <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis 
                  dataKey="timestamp" 
                  tickFormatter={(val) => format(new Date(val), 'MMM dd')} 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#94A3B8' }}
                />
                <YAxis 
                  domain={['dataMin - 2', 'dataMax + 2']} 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#94A3B8' }}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={3} fillOpacity={1} fill="url(#colorWeight)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Blood Pressure Trends" subtitle="Systolic vs Diastolic">
          <div className="h-[300px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={MOCK_BP_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#94A3B8' }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#94A3B8' }}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="systolic" stroke="#F43F5E" strokeWidth={3} dot={{ r: 4, fill: '#F43F5E' }} />
                <Line type="monotone" dataKey="diastolic" stroke="#10B981" strokeWidth={3} dot={{ r: 4, fill: '#10B981' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card title="Health Log History">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="pb-4 font-semibold text-slate-400 text-xs uppercase tracking-wider">Date</th>
                <th className="pb-4 font-semibold text-slate-400 text-xs uppercase tracking-wider">Metric</th>
                <th className="pb-4 font-semibold text-slate-400 text-xs uppercase tracking-wider">Value</th>
                <th className="pb-4 font-semibold text-slate-400 text-xs uppercase tracking-wider">Status</th>
                <th className="pb-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {MOCK_HEALTH_DATA.map(metric => (
                <tr key={metric.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 text-sm">{format(metric.timestamp, 'MMM dd, yyyy')}</td>
                  <td className="py-4">
                    <div className="flex items-center gap-2">
                      {metric.type === 'weight' ? <Scale size={16} className="text-blue-500" /> : <Activity size={16} className="text-rose-500" />}
                      <span className="text-sm font-medium capitalize">{metric.type.replace('_', ' ')}</span>
                    </div>
                  </td>
                  <td className="py-4 text-sm font-bold">{metric.value} {metric.unit}</td>
                  <td className="py-4"><Badge variant="success">Normal</Badge></td>
                  <td className="py-4 text-right">
                    <button className="text-slate-400 hover:text-slate-600 transition-colors">
                      <ChevronRight size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function AppointmentsView() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <Card title="Upcoming Appointments">
          <div className="space-y-6">
            {MOCK_APPOINTMENTS.map(appt => (
              <div key={appt.id} className="flex gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="w-16 h-16 rounded-2xl bg-white shadow-sm flex flex-col items-center justify-center text-rose-500">
                  <span className="text-xs font-bold uppercase">{format(appt.date, 'MMM')}</span>
                  <span className="text-2xl font-black leading-none">{format(appt.date, 'dd')}</span>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">{appt.title}</h4>
                      <p className="text-slate-500 flex items-center gap-1 mt-1">
                        <Stethoscope size={14} />
                        {appt.provider}
                      </p>
                    </div>
                    <Badge variant="default">{appt.type}</Badge>
                  </div>
                  <div className="mt-4 flex items-center gap-4 text-sm text-slate-400">
                    <span className="flex items-center gap-1"><Calendar size={14} /> {format(appt.date, 'h:mm a')}</span>
                    <span className="flex items-center gap-1">📍 {appt.location}</span>
                  </div>
                  <div className="mt-6 flex gap-3">
                    <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold hover:bg-slate-50 transition-colors">Reschedule</button>
                    <button className="px-4 py-2 bg-rose-500 text-white rounded-xl text-sm font-semibold hover:bg-rose-600 transition-colors">Confirm</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="space-y-6">
        <Card title="Care Team">
          <div className="space-y-4">
            {[
              { name: 'Dr. Sarah Mitchell', role: 'Obstetrician', img: 'https://picsum.photos/seed/doc1/100/100' },
              { name: 'Dr. Michael Chen', role: 'Genetic Counselor', img: 'https://picsum.photos/seed/doc2/100/100' },
              { name: 'Elena Rodriguez', role: 'Nutritionist', img: 'https://picsum.photos/seed/doc3/100/100' },
            ].map((member, i) => (
              <div key={i} className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer">
                <img src={member.img} className="w-10 h-10 rounded-full object-cover" alt={member.name} referrerPolicy="no-referrer" />
                <div>
                  <p className="text-sm font-semibold">{member.name}</p>
                  <p className="text-xs text-slate-500">{member.role}</p>
                </div>
                <button className="ml-auto p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                  <Bell size={16} />
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Quick Actions" className="bg-rose-500 text-white border-none shadow-lg shadow-rose-200">
          <div className="space-y-2">
            <button className="w-full flex items-center justify-between p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-colors">
              <span className="text-sm font-medium">Request Prescription</span>
              <ChevronRight size={16} />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-colors">
              <span className="text-sm font-medium">Message Care Team</span>
              <ChevronRight size={16} />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-colors">
              <span className="text-sm font-medium">Upload Lab Results</span>
              <ChevronRight size={16} />
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function MedicationsView() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <Card title="Active Medications" subtitle="Daily schedule and compliance">
          <div className="space-y-4">
            {MOCK_MEDICATIONS.map(med => (
              <div key={med.id} className="p-6 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center text-blue-500">
                  <Pill size={28} />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-lg font-bold">{med.name}</h4>
                        {med.remaining < 7 && (
                          <Badge variant="error">Low Supply</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-500">{med.dosage} • {med.frequency}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Next Dose</p>
                      <p className="text-sm font-bold text-blue-600 flex items-center gap-1 justify-end">
                        <Clock size={14} />
                        {med.time}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-xs mb-1 font-medium">
                      <span className="text-slate-500">Supply Remaining</span>
                      <span className="text-slate-900">{med.remaining} / {med.total} days</span>
                    </div>
                    <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full transition-all duration-1000",
                          med.remaining < 7 ? "bg-rose-500" : "bg-blue-500"
                        )}
                        style={{ width: `${(med.remaining / med.total) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                <button className="p-3 bg-white border border-slate-200 rounded-xl text-emerald-500 hover:bg-emerald-50 transition-colors shadow-sm">
                  <CheckCircle2 size={24} />
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Medication Reminders" subtitle="Push notification settings">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                  <Bell size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold">Smart Reminders</p>
                  <p className="text-xs text-slate-500">AI-optimized timing based on your routine</p>
                </div>
              </div>
              <div className="w-12 h-6 bg-rose-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
                  <AlertCircle size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold">Refill Alerts</p>
                  <p className="text-xs text-slate-500">Notify when supply is below 7 days</p>
                </div>
              </div>
              <div className="w-12 h-6 bg-rose-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div className="space-y-6">
        <Card title="Safety Checker" className="bg-blue-600 text-white border-none shadow-lg shadow-blue-200">
          <p className="text-sm opacity-90 mb-4">Check if a medication or supplement is safe during pregnancy.</p>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search medication..." 
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-sm placeholder:text-white/50 focus:outline-none focus:bg-white/20 transition-all"
            />
          </div>
          <button className="w-full mt-4 py-2 bg-white text-blue-600 rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors">
            Run Safety Scan
          </button>
        </Card>

        <Card title="Pharmacy Info">
          <div className="space-y-3">
            <div className="p-3 border border-slate-100 rounded-xl">
              <p className="text-xs font-bold text-slate-400 uppercase">Primary Pharmacy</p>
              <p className="text-sm font-bold mt-1">CVS Pharmacy #4821</p>
              <p className="text-xs text-slate-500">123 Health St, Downtown</p>
              <p className="text-xs text-blue-500 font-medium mt-2">(555) 123-4567</p>
            </div>
            <button className="w-full py-2 text-sm font-semibold text-rose-500 hover:bg-rose-50 rounded-xl transition-colors">
              Transfer Prescription
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function SystemMonitorView() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredServices = ALL_SERVICES.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.domain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const healthyCount = ALL_SERVICES.filter(s => s.status === 'healthy').length;
  const degradedCount = ALL_SERVICES.filter(s => s.status === 'degraded').length;

  return (
    <div className="space-y-8">
      {/* Infrastructure Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-emerald-50 border-emerald-100">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center text-white">
              <ShieldCheck size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-600 uppercase tracking-wider">System Health</p>
              <p className="text-2xl font-bold text-emerald-700">99.8%</p>
            </div>
          </div>
        </Card>
        <Card className="bg-blue-50 border-blue-100">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center text-white">
              <Zap size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-blue-600 uppercase tracking-wider">Active Services</p>
              <p className="text-2xl font-bold text-blue-700">{ALL_SERVICES.length}</p>
            </div>
          </div>
        </Card>
        <Card className="bg-amber-50 border-amber-100">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center text-white">
              <AlertCircle size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-600 uppercase tracking-wider">Incidents</p>
              <p className="text-2xl font-bold text-amber-700">{degradedCount} Degraded</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Service Registry */}
      <Card title="Microservice Registry" subtitle="Real-time status of the 500-service mesh">
        <div className="mb-6 flex gap-4">
          <div className="flex-1 relative">
            <input 
              type="text" 
              placeholder="Search services by name or domain..." 
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Server className="absolute left-3 top-2.5 text-slate-400" size={18} />
          </div>
          <select className="px-4 py-2 rounded-xl border border-slate-200 focus:outline-none bg-white text-sm">
            <option>All Domains</option>
            <option>Health Metrics</option>
            <option>User & Profile</option>
            <option>Analytics</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
          {filteredServices.map(svc => (
            <div key={svc.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col gap-2 hover:border-rose-200 transition-colors group">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "w-2 h-2 rounded-full animate-pulse",
                    svc.status === 'healthy' ? 'bg-emerald-500' : 'bg-amber-500'
                  )}></div>
                  <h5 className="font-bold text-sm truncate max-w-[150px]">{svc.name}</h5>
                </div>
                <span className="text-[10px] font-mono text-slate-400">{svc.id}</span>
              </div>
              <div className="flex justify-between items-end mt-2">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Domain</p>
                  <p className="text-xs text-slate-600">{svc.domain}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Latency</p>
                  <p className={cn(
                    "text-xs font-mono",
                    svc.latency > 100 ? 'text-rose-500' : 'text-emerald-600'
                  )}>{svc.latency}ms</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
