import { PregnancyState, HealthMetric, Symptom, Appointment, ServiceStatus, AppNotification, Medication } from './types';
import { addDays, subMinutes, differenceInDays, differenceInWeeks } from 'date-fns';

// Simulated data for the "500 Microservices"
export const MOCK_SERVICES: ServiceStatus[] = [
  { id: 'usr-001', name: 'User Registration', domain: 'User & Profile', status: 'healthy', latency: 12 },
  { id: 'tr-001', name: 'Due Date Calc', domain: 'Pregnancy Tracking', status: 'healthy', latency: 8 },
  { id: 'hm-001', name: 'BP Logger', domain: 'Health Metrics', status: 'healthy', latency: 15 },
  { id: 'hm-002', name: 'Weight Tracker', domain: 'Health Metrics', status: 'healthy', latency: 14 },
  { id: 'ap-001', name: 'Appt Scheduler', domain: 'Appointment', status: 'healthy', latency: 22 },
  { id: 'nt-001', name: 'Meal Planner', domain: 'Nutrition', status: 'healthy', latency: 45 },
  { id: 'ex-001', name: 'Activity Logger', domain: 'Exercise', status: 'degraded', latency: 120 },
  { id: 'fd-001', name: '3D Renderer', domain: 'Fetal Dev', status: 'healthy', latency: 35 },
  { id: 'sy-001', name: 'Symptom Logger', domain: 'Symptoms', status: 'healthy', latency: 10 },
  { id: 'no-001', name: 'Push Sender', domain: 'Notifications', status: 'healthy', latency: 5 },
];

// Generate more simulated services to reach the "500" feel in UI
export const ALL_SERVICES: ServiceStatus[] = [
  ...MOCK_SERVICES,
  ...Array.from({ length: 490 }).map((_, i) => ({
    id: `svc-${i + 10}`,
    name: `Microservice ${i + 10}`,
    domain: ['Analytics', 'Integration', 'Infrastructure', 'Social', 'Medication'][Math.floor(Math.random() * 5)],
    status: Math.random() > 0.98 ? 'degraded' : 'healthy',
    latency: Math.floor(Math.random() * 50) + 5,
  })) as ServiceStatus[]
];

export const MOCK_PREGNANCY: PregnancyState = {
  startDate: new Date(2025, 9, 15), // Oct 15, 2025
  dueDate: addDays(new Date(2025, 9, 15), 280),
  currentWeek: 24,
  currentDay: 3,
  babySize: 'Ear of Corn',
  babyImage: 'https://picsum.photos/seed/corn/400/400',
};

export const MOCK_HEALTH_DATA: HealthMetric[] = [
  { id: '1', type: 'weight', value: '65', unit: 'kg', timestamp: new Date(2026, 2, 20) },
  { id: '2', type: 'weight', value: '65.5', unit: 'kg', timestamp: new Date(2026, 2, 22) },
  { id: '3', type: 'weight', value: '66.2', unit: 'kg', timestamp: new Date(2026, 2, 25) },
  { id: '4', type: 'weight', value: '66.8', unit: 'kg', timestamp: new Date(2026, 2, 28) },
];

export const MOCK_BP_DATA = [
  { date: 'Mar 20', systolic: 118, diastolic: 78 },
  { date: 'Mar 22', systolic: 120, diastolic: 80 },
  { date: 'Mar 25', systolic: 115, diastolic: 75 },
  { date: 'Mar 28', systolic: 122, diastolic: 82 },
];

export const MOCK_APPOINTMENTS: Appointment[] = [
  { id: '1', title: 'Routine Checkup', provider: 'Dr. Sarah Mitchell', date: addDays(new Date(), 2), location: 'Maternal Health Center', type: 'checkup' },
  { id: '2', title: 'Glucose Tolerance Test', provider: 'LabCorp', date: addDays(new Date(), 7), location: 'Downtown Lab', type: 'lab' },
];

export const MOCK_SYMPTOMS: Symptom[] = [
  { id: '1', type: 'Nausea', severity: 'low', timestamp: new Date() },
  { id: '2', type: 'Back Pain', severity: 'medium', timestamp: new Date() },
];

export const MOCK_MEDICATIONS: Medication[] = [
  { id: '1', name: 'Prenatal Vitamin', dosage: '1 Tablet', frequency: 'Daily', time: '08:00 AM', remaining: 24, total: 30 },
  { id: '2', name: 'Folic Acid', dosage: '400mcg', frequency: 'Daily', time: '08:00 AM', remaining: 4, total: 60 },
  { id: '3', name: 'Iron Supplement', dosage: '65mg', frequency: 'Every other day', time: '07:00 PM', remaining: 10, total: 20 },
];

export const MOCK_NOTIFICATIONS: AppNotification[] = [
  { 
    id: 'n4', 
    title: 'Refill Alert: Folic Acid', 
    message: 'Low supply (4 days remaining). Please refill your 400mcg dosage.', 
    type: 'medication', 
    timestamp: new Date(), 
    read: false, 
    priority: 'high' 
  },
  { 
    id: 'n1', 
    title: 'Medication Reminder', 
    message: 'Time to take your Prenatal Vitamin.', 
    type: 'medication', 
    timestamp: subMinutes(new Date(), 15), 
    read: false, 
    priority: 'high' 
  },
  { 
    id: 'n2', 
    title: 'Upcoming Appointment', 
    message: 'Routine checkup with Dr. Sarah Mitchell in 2 days.', 
    type: 'appointment', 
    timestamp: subMinutes(new Date(), 120), 
    read: true, 
    priority: 'medium' 
  },
  { 
    id: 'n3', 
    title: 'System Update', 
    message: 'Microservice "Activity Logger" is back online.', 
    type: 'system', 
    timestamp: subMinutes(new Date(), 300), 
    read: true, 
    priority: 'low' 
  },
];
