export interface HealthMetric {
  id: string;
  type: 'blood_pressure' | 'weight' | 'glucose' | 'temperature';
  value: string;
  unit: string;
  timestamp: Date;
}

export interface Symptom {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: Date;
  notes?: string;
}

export interface Appointment {
  id: string;
  title: string;
  provider: string;
  date: Date;
  location: string;
  type: 'checkup' | 'ultrasound' | 'lab' | 'telehealth';
}

export interface PregnancyState {
  startDate: Date;
  dueDate: Date;
  currentWeek: number;
  currentDay: number;
  babySize: string;
  babyImage: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'appointment' | 'medication' | 'health' | 'system';
  timestamp: Date;
  read: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  time: string;
  remaining: number;
  total: number;
}

export interface ServiceStatus {
  id: string;
  name: string;
  domain: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
}
